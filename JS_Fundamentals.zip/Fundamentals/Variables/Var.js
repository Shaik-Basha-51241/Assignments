var a = 20;  
var b = 5; 
var c = 24; 
var d = a - b + c;  
console.log();  
