function nagur(){  
    var xyz=100;
    }  
    