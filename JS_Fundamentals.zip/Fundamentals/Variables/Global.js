var value=524;
function method1(){  
console.log(value);  
} 
var Name = "Nagur"; 
function method2(){  
console.log(Name);  
}  
method1(); 
method2();  
