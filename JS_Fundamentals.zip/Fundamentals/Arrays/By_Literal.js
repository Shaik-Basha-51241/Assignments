var emp=["Nagur","Basha", "Shaik"];  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  
