var i;  
var emp = new Array();  
emp[0] = "Nagur";  
emp[1] = "Basha";  
emp[2] = "Shaik";
  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  