var a=24;  
if(a%2==0){  
console.log("a is even number");  
}  
else{  
console.log("a is odd number");  
}  
