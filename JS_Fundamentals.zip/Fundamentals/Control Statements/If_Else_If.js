var a=24;  
if(a==5){  
console.log("a is equal to 10");  
}  
else if(a==12){  
console.log("a is equal to 15");  
}  
else if(a==24){  
console.log("a is equal to 24");  
}  
else{  
console.log("a is not equal to 5, 12 or 24");  
}  
