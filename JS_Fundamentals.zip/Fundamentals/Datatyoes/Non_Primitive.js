// Object Datatype
var Stu = new Object();
Stu.name = "Nagur";
Stu.reg_no = 211801340007;
Stu.branch = "CSE";

console.log(Stu.name);
console.log(Stu.reg_no);
console.log(Stu.branch);

// Array Datatype
var a = new Array(100,104,108);
console.log(a);
