var x = 24;  
var y = 5; 
// + (Addition)
var a=x+y;  
console.log(a);

// - (Subtraction)
var b=x-y;  
console.log(b);

// * (Multiplication)
var c=x*y;  
console.log(c);

// / (Division)
var d=x/y;  
console.log(d);

// % (Modulus)
var e=x%y;  
console.log(e);
