// AND Operator (&)
let x = 6 & 7;
console.log(x);

// OR Operator
let y = 6 | 10;
console.log(y);

// XOR Operator
let z = 5 ^ 9;
console.log(z);

// Left Shift
let a = 6 << 7;
console.log(a);

// Right Shift
let b = 7 >> 6;
console.log(b);

// Zerofill Right Shift
let c = 4 >>> 7;
console.log(c);
