// ++ (Increment)
var x = 24;  
var y = 5;  
var A=++x;
var B=++y;
console.log(A,B);

// -- (Decrement) 
var A=--x;
var B=--y;
console.log(A,B);