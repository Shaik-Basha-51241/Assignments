let b = 5;
let c = 24;
(b<c) ? console.log("True") : console.log("False");
