// Logical AND (&&)
let name = "Nagur";
let myname = "Basha";
let a = 5;
let b = 24;
let c = 24;

if(a<b && c == b){
    console.log("a is lessthan b and c is same as b");
}

if(b==c || a>b){
    console.log("Second if Statement is true");
}
if(1){
    console.log(!(a==b));
}
