// Relational Operators - (==,===,!=,<=,>=,<,>)

var x = 10;
var y = 50;
var z = 25;
if(x == z){
    console.log("x is equal to z");
}
else{
    console.log("x is not equal to z");
}

if(x<y){
    console.log("x is less than y");
}
else{
    console.log("x is greater than y");
}

if(y>x){
    console.log("y is greater than x");
}
else{
    console.log("y  is lessthan x");
}

if(x === y){
    console.log("x is equal to y and assign the value to tha x by y");
}

if(x!=y){
    console.log("x is not equal to y");
}
