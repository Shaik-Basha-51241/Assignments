function diff(a,b)
{
console.log(a - b);
}
var result = diff(24,5);