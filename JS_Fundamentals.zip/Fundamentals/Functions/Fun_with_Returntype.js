function add(){
    let a = 5;
    let b = 12;
    return a + b;
}
var a = add();
console.log(a);