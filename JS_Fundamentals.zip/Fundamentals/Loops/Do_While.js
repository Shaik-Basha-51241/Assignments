var i=5;  
do{  
console.log(i);  
i++;  
}while (i<=12);
