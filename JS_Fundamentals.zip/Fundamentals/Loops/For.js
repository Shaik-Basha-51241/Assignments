for(let i = 0;i<5;i++){
    console.log(i);
    }
    for(let a = 5;a<=12;a++){
    if(a%2 == 0){
    console.log(a);
    }
    }
    