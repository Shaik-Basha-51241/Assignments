const fruits = ["Apple", "orange", "Banana"];
let text = "";
for (let x of fruits) {
  text += x + " ";
}
console.log(text);