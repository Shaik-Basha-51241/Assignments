var i=5;  
while (i<=12)  
{  
console.log(i);  
i++;  
}  
